import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Zap, Wind, Battery, Smartphone, BarChart4 } from 'lucide-react';

const SolutionSection: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section className="py-20 px-4 bg-black" id="solution">
      <div className="container mx-auto">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="text-center mb-16"
        >
          <motion.h2 
            variants={itemVariants}
            className="text-4xl md:text-5xl font-['Bebas_Neue'] mb-6 neon-text"
          >
            Nuestra <span className="text-[#00FF7F]">Solución</span>
          </motion.h2>
          
          <motion.p 
            variants={itemVariants}
            className="text-xl max-w-3xl mx-auto"
          >
            T-Wind42 funciona como un sistema inteligente de microgeneración energética urbana aprovechando el viento generado por vehículos.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - System Components */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
            className="lg:col-span-1"
          >
            <motion.h3
              variants={itemVariants}
              className="text-2xl font-['Bebas_Neue'] mb-6 border-b border-[#00FF7F] pb-2"
            >
              Componentes del Sistema
            </motion.h3>

            <motion.div variants={itemVariants} className="mb-6 flex items-start">
              <Wind className="text-[#00FF7F] h-8 w-8 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h4 className="text-xl font-['Bebas_Neue'] mb-1">Turbinas Savonius</h4>
                <p className="text-sm text-gray-300">
                  Turbinas eólicas verticales diseñadas específicamente para capturar el viento generado por el tráfico vehicular.
                </p>
              </div>
            </motion.div>
            
            <motion.div variants={itemVariants} className="mb-6 flex items-start">
              <Battery className="text-[#00FF7F] h-8 w-8 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h4 className="text-xl font-['Bebas_Neue'] mb-1">Almacenamiento Energético</h4>
                <p className="text-sm text-gray-300">
                  Baterías de litio o de segunda vida para almacenar la energía generada y alimentar dispositivos de baja potencia.
                </p>
              </div>
            </motion.div>
            
            <motion.div variants={itemVariants} className="mb-6 flex items-start">
              <Zap className="text-[#00FF7F] h-8 w-8 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h4 className="text-xl font-['Bebas_Neue'] mb-1">Sensores Integrados</h4>
                <p className="text-sm text-gray-300">
                  Sensores de CO₂, temperatura, humedad y otros indicadores ambientales para monitoreo en tiempo real.
                </p>
              </div>
            </motion.div>
            
            <motion.div variants={itemVariants} className="flex items-start">
              <Smartphone className="text-[#00FF7F] h-8 w-8 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h4 className="text-xl font-['Bebas_Neue'] mb-1">Plataforma IoT y App</h4>
                <p className="text-sm text-gray-300">
                  Sistema conectado que permite visualizar el estado de cada unidad, generación energética y métricas ambientales.
                </p>
              </div>
            </motion.div>
          </motion.div>
          
          {/* Center Column - Illustration */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={inView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="lg:col-span-1 flex justify-center items-center"
          >
            <div className="relative w-full max-w-sm h-96 bg-gradient-to-b from-[#00FF7F10] to-transparent rounded-lg p-1">
              <div className="absolute inset-0 border border-[#00FF7F] rounded-lg opacity-50"></div>
              <div className="w-full h-full flex items-center justify-center">
                <img 
                  src="/Imagen de WhatsApp 2025-05-31 a las 17.02.14_d0569af3.jpg" 
                  alt="T-Wind42 Concepto" 
                  className="w-full h-full object-cover rounded-lg"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent rounded-lg"></div>
                <div className="absolute bottom-0 left-0 right-0 p-4 text-center">
                  <span className="font-['Bebas_Neue'] text-[#00FF7F] text-xl">Microgeneración Urbana</span>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* Right Column - How It Works */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
            className="lg:col-span-1"
          >
            <motion.h3
              variants={itemVariants}
              className="text-2xl font-['Bebas_Neue'] mb-6 border-b border-[#00FF7F] pb-2"
            >
              Cómo Funciona
            </motion.h3>

            <motion.ol variants={itemVariants} className="relative border-l border-[#00FF7F]">
              <li className="mb-8 ml-6">
                <span className="absolute flex items-center justify-center w-6 h-6 bg-[#00FF7F] rounded-full -left-3 ring-8 ring-black">
                  <span className="text-black font-bold">1</span>
                </span>
                <h4 className="text-lg font-['Bebas_Neue'] mb-1">Captura de Energía</h4>
                <p className="text-sm text-gray-300">
                  Las turbinas captan el viento generado por vehículos en rutas y avenidas con alto tránsito.
                </p>
              </li>
              
              <li className="mb-8 ml-6">
                <span className="absolute flex items-center justify-center w-6 h-6 bg-[#00FF7F] rounded-full -left-3 ring-8 ring-black">
                  <span className="text-black font-bold">2</span>
                </span>
                <h4 className="text-lg font-['Bebas_Neue'] mb-1">Conversión y Almacenamiento</h4>
                <p className="text-sm text-gray-300">
                  La energía cinética se convierte en electricidad mediante un generador y se almacena en baterías.
                </p>
              </li>
              
              <li className="mb-8 ml-6">
                <span className="absolute flex items-center justify-center w-6 h-6 bg-[#00FF7F] rounded-full -left-3 ring-8 ring-black">
                  <span className="text-black font-bold">3</span>
                </span>
                <h4 className="text-lg font-['Bebas_Neue'] mb-1">Monitoreo Ambiental</h4>
                <p className="text-sm text-gray-300">
                  Los sensores recopilan datos ambientales y de rendimiento en tiempo real.
                </p>
              </li>
              
              <li className="ml-6">
                <span className="absolute flex items-center justify-center w-6 h-6 bg-[#00FF7F] rounded-full -left-3 ring-8 ring-black">
                  <span className="text-black font-bold">4</span>
                </span>
                <h4 className="text-lg font-['Bebas_Neue'] mb-1">Análisis Inteligente</h4>
                <p className="text-sm text-gray-300">
                  La IA analiza los datos para optimizar el rendimiento, predecir necesidades de mantenimiento y proporcionar insights ambientales.
                </p>
              </li>
            </motion.ol>
          </motion.div>
        </div>
        
        {/* Applications */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-16 p-6 bg-black bg-opacity-50 border border-[#00FF7F] rounded-lg"
        >
          <div className="flex items-center mb-4">
            <BarChart4 className="text-[#00FF7F] h-8 w-8 mr-3" />
            <h3 className="text-2xl font-['Bebas_Neue']">Aplicaciones</h3>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 rounded-lg hover:bg-[#00FF7F10] transition-all duration-300">
              <div className="w-12 h-12 mx-auto bg-[#00FF7F20] rounded-full flex items-center justify-center mb-2">
                <span className="text-[#00FF7F] text-xl">💡</span>
              </div>
              <p className="text-sm">Iluminación Vial LED</p>
            </div>
            
            <div className="text-center p-3 rounded-lg hover:bg-[#00FF7F10] transition-all duration-300">
              <div className="w-12 h-12 mx-auto bg-[#00FF7F20] rounded-full flex items-center justify-center mb-2">
                <span className="text-[#00FF7F] text-xl">🔋</span>
              </div>
              <p className="text-sm">Cargadores Urbanos</p>
            </div>
            
            <div className="text-center p-3 rounded-lg hover:bg-[#00FF7F10] transition-all duration-300">
              <div className="w-12 h-12 mx-auto bg-[#00FF7F20] rounded-full flex items-center justify-center mb-2">
                <span className="text-[#00FF7F] text-xl">🚦</span>
              </div>
              <p className="text-sm">Señalética Activa</p>
            </div>
            
            <div className="text-center p-3 rounded-lg hover:bg-[#00FF7F10] transition-all duration-300">
              <div className="w-12 h-12 mx-auto bg-[#00FF7F20] rounded-full flex items-center justify-center mb-2">
                <span className="text-[#00FF7F] text-xl">📊</span>
              </div>
              <p className="text-sm">Monitoreo Ambiental</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SolutionSection;