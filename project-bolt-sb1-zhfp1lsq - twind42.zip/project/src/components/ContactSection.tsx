import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Mail, Phone, MapPin, FileText, Video } from 'lucide-react';

const ContactSection: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const mailtoLink = `mailto:ayulgabriel@gmail.com?subject=Mensaje de ${encodeURIComponent(formData.name)}&body=Nombre: ${encodeURIComponent(formData.name)}%0D%0AEmail: ${encodeURIComponent(formData.email)}%0D%0AMensaje: ${encodeURIComponent(formData.message)}`;
    
    window.location.href = mailtoLink;
    
    setFormData({
      name: '',
      email: '',
      message: '',
    });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section className="py-20 px-4 bg-black" id="contact">
      <div className="container mx-auto">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="text-center mb-16"
        >
          <motion.h2 
            variants={itemVariants}
            className="text-4xl md:text-5xl font-['Bebas_Neue'] mb-6 neon-text"
          >
            <span className="text-[#00FF7F]">Contacta</span> con Nosotros
          </motion.h2>
          
          <motion.p 
            variants={itemVariants}
            className="text-xl max-w-3xl mx-auto"
          >
            ¿Interesado en nuestra solución? ¿Tienes preguntas o quieres colaborar? Estamos aquí para ayudarte.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
          >
            <motion.form 
              variants={itemVariants} 
              onSubmit={handleSubmit}
              className="bg-black bg-opacity-60 p-8 rounded-lg border border-[#00FF7F] shadow-[0_0_20px_rgba(0,255,127,0.2)]"
            >
              <h3 className="text-2xl font-['Bebas_Neue'] mb-6 text-center">Envíanos un Mensaje</h3>
              
              <div className="mb-4">
                <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-1">
                  Nombre
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full p-3 bg-black border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-[#00FF7F] focus:border-transparent transition-all duration-300 text-white"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full p-3 bg-black border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-[#00FF7F] focus:border-transparent transition-all duration-300 text-white"
                  required
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-1">
                  Mensaje
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={5}
                  className="w-full p-3 bg-black border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-[#00FF7F] focus:border-transparent transition-all duration-300 text-white resize-none"
                  required
                ></textarea>
              </div>
              
              <button
                type="submit"
                className="w-full bg-[#00FF7F] text-black font-bold py-3 px-4 rounded-md uppercase tracking-wider hover:bg-[#00CC66] transition-all duration-300 neon-button"
              >
                Enviar Mensaje
              </button>
            </motion.form>
          </motion.div>
          
          {/* Contact Info and Resources */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
          >
            <motion.div 
              variants={itemVariants}
              className="mb-8"
            >
              <h3 className="text-2xl font-['Bebas_Neue'] mb-6 border-b border-[#00FF7F] pb-2">
                Información de Contacto
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <Mail className="text-[#00FF7F] h-6 w-6 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Email</h4>
                    <p className="text-gray-300">ayulgabriel@gmail.com</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Phone className="text-[#00FF7F] h-6 w-6 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Teléfono</h4>
                    <p className="text-gray-300">+54 297 4132691</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <MapPin className="text-[#00FF7F] h-6 w-6 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Ubicación</h4>
                    <p className="text-gray-300">Comodoro Rivadavia, Chubut, Argentina</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div variants={itemVariants}>
              <h3 className="text-2xl font-['Bebas_Neue'] mb-6 border-b border-[#00FF7F] pb-2">
                Recursos del Proyecto
              </h3>
              
              <div className="grid grid-cols-1 gap-4">
                <a 
                  href="https://drive.google.com/file/d/1wqDnlRvc21HuxLvmXWSXJFU4zT1XQ58s/view?usp=drive_link"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-6 bg-black bg-opacity-60 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.3)] transition-all duration-300 group h-24"
                >
                  <FileText className="text-[#00FF7F] h-8 w-8 mr-3 group-hover:scale-110 transition-transform duration-300" />
                  <div>
                    <h4 className="font-['Bebas_Neue'] text-lg group-hover:text-[#00FF7F] transition-colors duration-300">Presentación</h4>
                    <p className="text-xs text-gray-400">Ver en línea</p>
                  </div>
                </a>
                
                <a 
                  href="https://drive.google.com/file/d/1wzdOdIDkuYdaAp5I8CnktZciiEa19M-x/view?usp=drive_link"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-6 bg-black bg-opacity-60 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.3)] transition-all duration-300 group h-24"
                >
                  <Video className="text-[#00FF7F] h-8 w-8 mr-3 group-hover:scale-110 transition-transform duration-300" />
                  <div>
                    <h4 className="font-['Bebas_Neue'] text-lg group-hover:text-[#00FF7F] transition-colors duration-300">Video Pitch</h4>
                    <p className="text-xs text-gray-400">Ver presentación del proyecto</p>
                  </div>
                </a>
              </div>
              
              <div className="mt-8 p-4 bg-[#00FF7F10] rounded-lg text-center">
                <h4 className="font-['Bebas_Neue'] text-lg mb-2">Modelo 3D Interactivo</h4>
                <p className="text-sm text-gray-300 mb-3">
                  Explora nuestro prototipo en 3D para entender mejor cómo funciona T-Wind42
                </p>
                <a 
                  href="https://www.tinkercad.com/things/g9fFwWh1DjG-energia-1/edit?returnTo=https%3A%2F%2Fwww.tinkercad.com%2Fdashboard%2Fdesigns%2F3d&sharecode=st69tVdKIMyDg99MmDA1WS-U8kJSBelTVn8oaVUDfFY"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block bg-[#00FF7F] text-black font-bold py-2 px-4 rounded-md hover:bg-[#00CC66] transition-all duration-300"
                >
                  Ver Modelo 3D
                </a>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;