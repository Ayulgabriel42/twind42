import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';

const TurbineBlades = () => {
  const turbine = useRef<THREE.Group>(null);
  const solarPanel = useRef<THREE.Group>(null);
  
  useFrame(() => {
    if (turbine.current) {
      turbine.current.rotation.y += 0.01;
    }
    if (solarPanel.current) {
      // Gentle oscillating movement for the solar panel
      solarPanel.current.rotation.x = Math.sin(Date.now() * 0.001) * 0.1 + 0.3;
    }
  });

  return (
    <group>
      {/* Base */}
      <mesh position={[0, -2, 0]}>
        <cylinderGeometry args={[1, 1.2, 0.3, 32]} />
        <meshStandardMaterial color="#666666" />
      </mesh>

      {/* Main Column */}
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[0.5, 0.5, 4, 32]} />
        <meshStandardMaterial color="#4A9" />
      </mesh>

      {/* Top Cap */}
      <mesh position={[0, 2, 0]}>
        <cylinderGeometry args={[0.6, 0.6, 0.2, 32]} />
        <meshStandardMaterial color="#FF8C42" />
      </mesh>

      {/* Solar Panel Mount */}
      <group ref={solarPanel} position={[0, 2.2, 0]}>
        {/* Panel Frame */}
        <mesh>
          <boxGeometry args={[1.4, 0.1, 1.4]} />
          <meshStandardMaterial color="#2D3748" />
        </mesh>
        {/* Solar Panel */}
        <mesh position={[0, 0.06, 0]}>
          <boxGeometry args={[1.2, 0.05, 1.2]} />
          <meshStandardMaterial color="#1E4D8C" metalness={0.8} roughness={0.2} />
        </mesh>
        {/* Panel Details */}
        <mesh position={[0, 0.08, 0]}>
          <gridHelper args={[1.1, 8, "#666666", "#666666"]} />
        </mesh>
      </group>

      {/* Rotating Turbine Section */}
      <group ref={turbine} position={[0, 0, 0]}>
        {/* Vertical Cylinder */}
        <mesh>
          <cylinderGeometry args={[0.8, 0.8, 3, 32]} />
          <meshStandardMaterial color="#4A9" transparent opacity={0.3} />
        </mesh>

        {/* Internal Structure */}
        {[0, 1, 2, 3].map((i) => (
          <mesh key={i} position={[
            0.4 * Math.cos((i * Math.PI) / 2),
            0,
            0.4 * Math.sin((i * Math.PI) / 2)
          ]}>
            <cylinderGeometry args={[0.05, 0.05, 3, 8]} />
            <meshStandardMaterial color="#666666" />
          </mesh>
        ))}

        {/* Horizontal Dividers */}
        {[-1, 0, 1].map((y) => (
          <mesh key={y} position={[0, y, 0]}>
            <torusGeometry args={[0.4, 0.02, 16, 32]} />
            <meshStandardMaterial color="#666666" />
          </mesh>
        ))}
      </group>
    </group>
  );
};

const WindTurbine: React.FC = () => {
  return (
    <div className="w-full h-full bg-black bg-opacity-50 rounded-full border border-[#00FF7F] shadow-[0_0_20px_rgba(0,255,127,0.3)]">
      <Canvas camera={{ position: [5, 2, 5], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} />
        <pointLight position={[-10, -10, -10]} intensity={0.5} color="#00FF7F" />
        <TurbineBlades />
        <OrbitControls 
          enableZoom={false} 
          autoRotate 
          autoRotateSpeed={2}
          maxPolarAngle={Math.PI / 2}
          minPolarAngle={Math.PI / 4}
        />
      </Canvas>
    </div>
  );
};

export default WindTurbine;