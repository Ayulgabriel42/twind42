import React, { useEffect, useRef } from 'react';
import { Link } from 'react-scroll';
import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';

const HeroSection: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!heroRef.current) return;
      
      const { clientX, clientY } = e;
      const x = clientX / window.innerWidth;
      const y = clientY / window.innerHeight;
      
      heroRef.current.style.backgroundPosition = `${50 + x * 10}% ${50 + y * 10}%`;
    };

    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <div 
      ref={heroRef}
      className="relative h-screen flex items-center justify-center bg-cover bg-center transition-all duration-300 ease-out"
      style={{ 
        backgroundImage: 'url("/fondo-comodoro-twind42.png")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black bg-opacity-40"></div>
      
      {/* Content */}
      <div className="container mx-auto px-4 z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-['Bebas_Neue'] text-white mb-4 neon-text">
            TWIND<span className="text-[#00FF7F]">42</span> ENERGÍA INNOVADORA
          </h1>
          
          <motion.p 
            className="text-xl md:text-2xl text-white mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            Por Gabriel Ayul, Gabriel Almonacid y Diego Calisaya
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1, duration: 0.5 }}
          >
            <Link
              to="about"
              spy={true}
              smooth={true}
              offset={-70}
              duration={500}
              className="inline-block bg-[#00FF7F] text-black font-bold py-3 px-8 rounded-full uppercase tracking-wider neon-button hover:bg-[#00CC66] transition-all duration-300 cursor-pointer"
            >
              NUESTRO PROYECTO
            </Link>
          </motion.div>
        </motion.div>
      </div>
      
      {/* Scroll Down Indicator */}
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white text-center cursor-pointer"
        animate={{ 
          y: [0, 10, 0],
        }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
          repeatType: "loop"
        }}
      >
        <Link
          to="about"
          spy={true}
          smooth={true}
          offset={-70}
          duration={500}
        >
          <ArrowDown className="h-8 w-8 mx-auto text-[#00FF7F]" />
          <span className="block mt-2 text-sm font-['Bebas_Neue']">SCROLL DOWN</span>
        </Link>
      </motion.div>
    </div>
  );
};

export default HeroSection;