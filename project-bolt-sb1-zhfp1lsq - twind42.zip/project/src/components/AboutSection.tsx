import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Wind, Lightbulb, Battery, Cpu } from 'lucide-react';
import WindTurbine from './WindTurbine';

const AboutSection: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section className="py-20 px-4 bg-black" id="about">
      <div className="container mx-auto">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="text-center mb-16"
        >
          <motion.h2 
            variants={itemVariants}
            className="text-4xl md:text-5xl font-['Bebas_Neue'] mb-6 neon-text"
          >
            Acerca de <span className="text-[#00FF7F]">T-WIND42</span>
          </motion.h2>
          
          <motion.p 
            variants={itemVariants}
            className="text-xl max-w-3xl mx-auto"
          >
            T-Wind42 es una solución innovadora de microgeneración de energía renovable que transforma el viento generado por el tráfico vehicular en electricidad útil.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex justify-center"
          >
            <div className="relative w-64 h-64 md:w-80 md:h-80">
              <WindTurbine />
            </div>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
          >
            <motion.p 
              variants={itemVariants}
              className="text-lg mb-6"
            >
              T-Wind42 es una solución innovadora de microgeneración de energía renovable que transforma el viento generado por el tráfico vehicular en electricidad, mediante turbinas verticales Savonius instaladas en rutas y avenidas urbanas.
            </motion.p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <motion.div 
                variants={itemVariants} 
                className="bg-black bg-opacity-50 p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.5)] transition-all duration-300"
              >
                <Wind className="text-[#00FF7F] h-10 w-10 mb-4" />
                <h3 className="text-xl font-['Bebas_Neue'] mb-2">Turbinas Verticales</h3>
                <p className="text-sm text-gray-300">Diseño tipo Savonius para máximo aprovechamiento del flujo de aire vehicular</p>
              </motion.div>
              
              <motion.div 
                variants={itemVariants} 
                className="bg-black bg-opacity-50 p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.5)] transition-all duration-300"
              >
                <Battery className="text-[#00FF7F] h-10 w-10 mb-4" />
                <h3 className="text-xl font-['Bebas_Neue'] mb-2">Almacenamiento Eficiente</h3>
                <p className="text-sm text-gray-300">Baterías optimizadas para cargas de dispositivos de baja potencia</p>
              </motion.div>
              
              <motion.div 
                variants={itemVariants} 
                className="bg-black bg-opacity-50 p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.5)] transition-all duration-300"
              >
                <Cpu className="text-[#00FF7F] h-10 w-10 mb-4" />
                <h3 className="text-xl font-['Bebas_Neue'] mb-2">Plataforma IoT</h3>
                <p className="text-sm text-gray-300">Monitoreo en tiempo real de generación energética y datos ambientales</p>
              </motion.div>
              
              <motion.div 
                variants={itemVariants} 
                className="bg-black bg-opacity-50 p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.5)] transition-all duration-300"
              >
                <Lightbulb className="text-[#00FF7F] h-10 w-10 mb-4" />
                <h3 className="text-xl font-['Bebas_Neue'] mb-2">Integración Urbana</h3>
                <p className="text-sm text-gray-300">Perfecta adaptación a infraestructuras viales existentes</p>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;