import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { AlertTriangle, CloudOff, Battery, Map } from 'lucide-react';

const ProblemSection: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section className="py-20 px-4 bg-black relative overflow-hidden" id="problem">
      {/* Background SVG pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <pattern id="pattern" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M0 20 L40 20 M20 0 L20 40" stroke="#00FF7F" strokeWidth="1" />
          </pattern>
          <rect x="0" y="0" width="100%" height="100%" fill="url(#pattern)" />
        </svg>
      </div>

      <div className="container mx-auto relative z-10">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="text-center mb-16"
        >
          <motion.h2 
            variants={itemVariants}
            className="text-4xl md:text-5xl font-['Bebas_Neue'] mb-6 neon-text"
          >
            El <span className="text-[#00FF7F]">Problema</span>
          </motion.h2>
          
          <motion.p 
            variants={itemVariants}
            className="text-xl max-w-3xl mx-auto"
          >
            Estamos abordando desafíos energéticos y ambientales críticos en entornos urbanos.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
            className="order-2 md:order-1"
          >
            <motion.div variants={itemVariants} className="mb-8 bg-black bg-opacity-50 p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.5)] transition-all duration-300">
              <div className="flex items-center mb-4">
                <AlertTriangle className="text-[#00FF7F] h-8 w-8 mr-3" />
                <h3 className="text-2xl font-['Bebas_Neue']">Dependencia de Combustibles Fósiles</h3>
              </div>
              <p className="text-gray-300">
                Las ciudades dependen excesivamente de fuentes de energía no renovables, contribuyendo a la contaminación y al cambio climático.
              </p>
            </motion.div>
            
            <motion.div variants={itemVariants} className="mb-8 bg-black bg-opacity-50 p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.5)] transition-all duration-300">
              <div className="flex items-center mb-4">
                <Battery className="text-[#00FF7F] h-8 w-8 mr-3" />
                <h3 className="text-2xl font-['Bebas_Neue']">Energía Desperdiciada</h3>
              </div>
              <p className="text-gray-300">
                El flujo de aire generado por vehículos en zonas urbanas representa una fuente de energía cinética completamente desaprovechada.
              </p>
            </motion.div>
            
            <motion.div variants={itemVariants} className="bg-black bg-opacity-50 p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.5)] transition-all duration-300">
              <div className="flex items-center mb-4">
                <CloudOff className="text-[#00FF7F] h-8 w-8 mr-3" />
                <h3 className="text-2xl font-['Bebas_Neue']">Falta de Monitoreo Ambiental</h3>
              </div>
              <p className="text-gray-300">
                La ausencia de sistemas de monitoreo ambiental en tiempo real dificulta la toma de decisiones basadas en datos para mejorar la calidad del aire.
              </p>
            </motion.div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="order-1 md:order-2"
          >
            <div className="h-full flex flex-col justify-center">
              <div className="relative rounded-lg overflow-hidden h-80 md:h-96 shadow-[0_0_30px_rgba(0,255,127,0.2)]">
                <Map className="absolute inset-0 text-[#00FF7F] opacity-10 h-full w-full" />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black"></div>
                <img 
                  src="/ChatGPT Image 31 may 2025, 02_52_06 p.m..png" 
                  alt="Contaminación urbana en Comodoro Rivadavia" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 p-6">
                  <h4 className="text-2xl font-['Bebas_Neue'] mb-2">Comodoro Rivadavia</h4>
                  <p className="text-sm text-gray-300">
                    Con su tráfico constante, la ciudad presenta condiciones ideales para implementar soluciones de microgeneración eólica urbana.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;