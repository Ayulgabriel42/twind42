import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Lightbulb, Briefcase, GraduationCap } from 'lucide-react';

const TeamSection: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6 },
    },
  };

  const teamMembers = [
    {
      name: 'Gabriel Ayul',
      age: 39,
      role: 'Emprendedor y estudiante en Lic. en inteligencia artificial y robótica',
      icon: <Lightbulb className="text-[#00FF7F] h-8 w-8" />,
      description: 'Aporta visión innovadora y conocimientos técnicos en IA y robótica al proyecto. Lidera el desarrollo de algoritmos predictivos y sistemas de monitoreo inteligente.',
      skills: ['Inteligencia Artificial', 'Robótica', 'Innovación', 'Emprendimiento'],
    },
    {
      name: 'Gabriel Almonacid',
      age: 25,
      role: 'Ingeniero industrial y emprendedor',
      icon: <Briefcase className="text-[#00FF7F] h-8 w-8" />,
      description: 'Contribuye con su experiencia en procesos industriales, optimización de recursos y gestión de proyectos para implementación y escalabilidad.',
      skills: ['Ingeniería Industrial', 'Gestión de Proyectos', 'Optimización de Procesos', 'Estrategia'],
    },
    {
      name: 'Diego Calisaya',
      age: 17,
      role: 'Bachiller en economía',
      icon: <GraduationCap className="text-[#00FF7F] h-8 w-8" />,
      description: 'Aporta perspectiva fresca sobre economía sostenible y circular, así como visión de las nuevas generaciones sobre problemas ambientales.',
      skills: ['Economía', 'Sustentabilidad', 'Análisis', 'Perspectiva Joven'],
    },
  ];

  return (
    <section className="py-20 px-4 bg-black relative" id="team">
      {/* Background gradient */}
      <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-[#00FF7F10] to-transparent"></div>
      <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-[#00FF7F10] to-transparent"></div>

      <div className="container mx-auto relative z-10">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="text-center mb-16"
        >
          <motion.h2 
            variants={itemVariants}
            className="text-4xl md:text-5xl font-['Bebas_Neue'] mb-6 neon-text"
          >
            Nuestro <span className="text-[#00FF7F]">Equipo</span>
          </motion.h2>
          
          <motion.p 
            variants={itemVariants}
            className="text-xl max-w-3xl mx-auto"
          >
            Un equipo multidisciplinario que combina distintas perspectivas y experiencias para crear soluciones innovadoras.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="bg-black bg-opacity-60 rounded-lg overflow-hidden border border-[#00FF7F] hover:shadow-[0_0_20px_rgba(0,255,127,0.3)] transition-all duration-300 group"
            >
              <div className="p-6">
                <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-[#00FF7F10] flex items-center justify-center border-2 border-[#00FF7F] group-hover:scale-110 transition-transform duration-300">
                  {member.icon}
                </div>
                
                <h3 className="text-2xl font-['Bebas_Neue'] text-center mb-1 group-hover:text-[#00FF7F] transition-colors duration-300">
                  {member.name}
                </h3>
                
                <p className="text-center text-gray-400 text-sm mb-4">
                  {member.age} años
                </p>
                
                <h4 className="text-center text-[#00FF7F] font-semibold mb-4 italic">
                  {member.role}
                </h4>
                
                <p className="text-gray-300 text-sm mb-6">
                  {member.description}
                </p>
                
                <div className="flex flex-wrap justify-center gap-2">
                  {member.skills.map((skill, skillIndex) => (
                    <span 
                      key={skillIndex}
                      className="text-xs bg-[#00FF7F20] text-[#00FF7F] px-3 py-1 rounded-full"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          variants={itemVariants}
          className="mt-16 text-center bg-[#00FF7F10] p-6 rounded-lg border border-[#00FF7F] max-w-3xl mx-auto"
        >
          <h3 className="text-2xl font-['Bebas_Neue'] mb-4">Nuestra Visión Compartida</h3>
          <p className="text-gray-300">
            Somos un equipo diverso que combina experiencia técnica, visión empresarial y perspectiva fresca. 
            Esta multiplicidad de enfoques nos permite abordar los problemas desde diferentes ángulos, 
            enriqueciendo nuestras soluciones y fortaleciendo nuestro impacto.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default TeamSection;