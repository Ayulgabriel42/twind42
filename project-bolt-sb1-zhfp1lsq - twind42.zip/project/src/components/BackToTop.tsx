import React, { useState, useEffect } from 'react';
import { animateScroll as scroll } from 'react-scroll';
import { ChevronUp } from 'lucide-react';

const BackToTop: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    scroll.scrollToTop({
      duration: 800,
      smooth: 'easeInOutQuart',
    });
  };

  return (
    <div 
      className={`fixed bottom-8 right-8 z-50 transition-all duration-300 ${
        isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90 pointer-events-none'
      }`}
    >
      <button
        onClick={scrollToTop}
        className="bg-black p-3 rounded-full border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.5)] transition-all duration-300 group"
        aria-label="Volver arriba"
      >
        <ChevronUp className="h-6 w-6 text-[#00FF7F] group-hover:animate-pulse" />
      </button>
    </div>
  );
};

export default BackToTop;