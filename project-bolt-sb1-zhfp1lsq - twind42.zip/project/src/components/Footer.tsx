import React from 'react';
import { Link } from 'react-scroll';
import { Wind, Github as GitHub, Twitter, Linkedin, Instagram, ArrowUp } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black py-12 border-t border-[#00FF7F30]">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="md:col-span-1">
            <div className="flex items-center mb-4">
              <Wind className="text-[#00FF7F] h-8 w-8 mr-2" />
              <span className="font-['Bebas_Neue'] text-2xl text-white">
                T-WIND<span className="text-[#00FF7F]">42</span>
              </span>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              Transformando el tráfico urbano en energía limpia para un futuro más sostenible.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-[#00FF7F] transition-colors duration-300">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#00FF7F] transition-colors duration-300">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#00FF7F] transition-colors duration-300">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#00FF7F] transition-colors duration-300">
                <GitHub className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div className="md:col-span-1">
            <h3 className="text-xl font-['Bebas_Neue'] mb-4 text-white">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              {['about', 'problem', 'solution', 'impact', 'technologies', 'team', 'contact'].map((section) => (
                <li key={section}>
                  <Link
                    to={section}
                    spy={true}
                    smooth={true}
                    offset={-70}
                    duration={500}
                    className="text-gray-400 hover:text-[#00FF7F] transition-colors duration-300 cursor-pointer"
                  >
                    {section.charAt(0).toUpperCase() + section.slice(1)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Legal */}
          <div className="md:col-span-1">
            <h3 className="text-xl font-['Bebas_Neue'] mb-4 text-white">Legal</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-[#00FF7F] transition-colors duration-300">
                  Términos y Condiciones
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#00FF7F] transition-colors duration-300">
                  Política de Privacidad
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#00FF7F] transition-colors duration-300">
                  Cookies
                </a>
              </li>
            </ul>
          </div>
          
          {/* Newsletter */}
          <div className="md:col-span-1">
            <h3 className="text-xl font-['Bebas_Neue'] mb-4 text-white">Newsletter</h3>
            <p className="text-gray-400 text-sm mb-4">
              Suscríbete para recibir las últimas noticias y actualizaciones sobre T-Wind42.
            </p>
            <form className="flex">
              <input
                type="email"
                placeholder="Tu email"
                className="flex-1 p-2 bg-black border border-gray-700 rounded-l-md focus:outline-none focus:ring-1 focus:ring-[#00FF7F] focus:border-transparent text-white"
              />
              <button
                type="submit"
                className="bg-[#00FF7F] text-black font-bold py-2 px-4 rounded-r-md hover:bg-[#00CC66] transition-all duration-300"
              >
                Enviar
              </button>
            </form>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-gray-800 text-center">
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} T-Wind42. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;