import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Leaf, Building2, Users, DollarSign } from 'lucide-react';

const ImpactSection: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6 },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section className="py-20 px-4 bg-black" id="impact">
      <div className="container mx-auto">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="text-center mb-16"
        >
          <motion.h2 
            variants={itemVariants}
            className="text-4xl md:text-5xl font-['Bebas_Neue'] mb-6 neon-text"
          >
            <span className="text-[#00FF7F]">Impacto</span> Esperado
          </motion.h2>
          
          <motion.p 
            variants={itemVariants}
            className="text-xl max-w-3xl mx-auto"
          >
            T-Wind42 genera un impacto multidimensional a nivel ambiental, urbano, social y económico.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Environmental Impact */}
          <motion.div
            variants={cardVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-[#00FF7F10] to-transparent p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.3)] transition-all duration-300"
          >
            <div className="flex items-center mb-4">
              <Leaf className="text-[#00FF7F] h-8 w-8 mr-3" />
              <h3 className="text-2xl font-['Bebas_Neue']">Impacto Ambiental</h3>
            </div>
            
            <ul className="space-y-3 text-gray-300">
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Generación de energía limpia sin emisiones ni impacto acústico</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Reducción de la huella de carbono urbana al sustituir fuentes fósiles</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Monitoreo ambiental en tiempo real, permitiendo políticas públicas basadas en datos</span>
              </li>
            </ul>
            
            <div className="mt-6 bg-black bg-opacity-50 p-4 rounded border border-[#00FF7F40]">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm">Reducción de CO₂</span>
                <span className="text-sm text-[#00FF7F]">85%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-[#00FF7F] h-2 rounded-full" style={{ width: '85%' }}></div>
              </div>
            </div>
          </motion.div>
          
          {/* Urban Impact */}
          <motion.div
            variants={cardVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-[#00FF7F10] to-transparent p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.3)] transition-all duration-300"
          >
            <div className="flex items-center mb-4">
              <Building2 className="text-[#00FF7F] h-8 w-8 mr-3" />
              <h3 className="text-2xl font-['Bebas_Neue']">Impacto Urbano</h3>
            </div>
            
            <ul className="space-y-3 text-gray-300">
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Mejora de infraestructura inteligente con iluminación autosuficiente</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Datos ambientales abiertos para planificación urbana</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Aprovechamiento de un recurso desaprovechado: el viento urbano generado por vehículos</span>
              </li>
            </ul>
            
            <div className="mt-6 bg-black bg-opacity-50 p-4 rounded border border-[#00FF7F40]">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm">Adaptabilidad urbana</span>
                <span className="text-sm text-[#00FF7F]">92%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-[#00FF7F] h-2 rounded-full" style={{ width: '92%' }}></div>
              </div>
            </div>
          </motion.div>
          
          {/* Social Impact */}
          <motion.div
            variants={cardVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-[#00FF7F10] to-transparent p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.3)] transition-all duration-300"
          >
            <div className="flex items-center mb-4">
              <Users className="text-[#00FF7F] h-8 w-8 mr-3" />
              <h3 className="text-2xl font-['Bebas_Neue']">Impacto Social y Educativo</h3>
            </div>
            
            <ul className="space-y-3 text-gray-300">
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Empoderamiento ciudadano a través de una app que muestra en tiempo real el impacto local</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Posibilidad de replicar la solución en colegios técnicos, universidades e industrias locales</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Generación de empleo local en manufactura, instalación y mantenimiento</span>
              </li>
            </ul>
            
            <div className="mt-6 bg-black bg-opacity-50 p-4 rounded border border-[#00FF7F40]">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm">Participación comunitaria</span>
                <span className="text-sm text-[#00FF7F]">78%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-[#00FF7F] h-2 rounded-full" style={{ width: '78%' }}></div>
              </div>
            </div>
          </motion.div>
          
          {/* Economic Impact */}
          <motion.div
            variants={cardVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
            transition={{ delay: 0.4 }}
            className="bg-gradient-to-br from-[#00FF7F10] to-transparent p-6 rounded-lg border border-[#00FF7F] hover:shadow-[0_0_15px_rgba(0,255,127,0.3)] transition-all duration-300"
          >
            <div className="flex items-center mb-4">
              <DollarSign className="text-[#00FF7F] h-8 w-8 mr-3" />
              <h3 className="text-2xl font-['Bebas_Neue']">Impacto Económico</h3>
            </div>
            
            <ul className="space-y-3 text-gray-300">
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Alternativa de bajo costo y alta escalabilidad para ciudades que no pueden afrontar grandes proyectos energéticos</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Posibilidad de comercializar datos ambientales a través de alianzas con municipios y ONGs</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00FF7F] mr-2">✓</span>
                <span>Retorno de inversión a través del ahorro energético y acuerdos de energía compartida (net metering)</span>
              </li>
            </ul>
            
            <div className="mt-6 bg-black bg-opacity-50 p-4 rounded border border-[#00FF7F40]">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm">ROI estimado</span>
                <span className="text-sm text-[#00FF7F]">65%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-[#00FF7F] h-2 rounded-full" style={{ width: '65%' }}></div>
              </div>
            </div>
          </motion.div>
        </div>
        
        {/* Beneficiaries */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-16"
        >
          <h3 className="text-2xl font-['Bebas_Neue'] mb-6 text-center">¿A Quiénes <span className="text-[#00FF7F]">Beneficia</span>?</h3>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="text-center p-4 bg-black bg-opacity-50 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] transition-all duration-300">
              <div className="w-16 h-16 mx-auto bg-[#00FF7F10] rounded-full flex items-center justify-center mb-3">
                <Building2 className="text-[#00FF7F] h-8 w-8" />
              </div>
              <h4 className="font-['Bebas_Neue'] mb-1">Ciudades y Municipios</h4>
              <p className="text-xs text-gray-400">Energía limpia y datos ambientales para planificación</p>
            </div>
            
            <div className="text-center p-4 bg-black bg-opacity-50 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] transition-all duration-300">
              <div className="w-16 h-16 mx-auto bg-[#00FF7F10] rounded-full flex items-center justify-center mb-3">
                <Users className="text-[#00FF7F] h-8 w-8" />
              </div>
              <h4 className="font-['Bebas_Neue'] mb-1">Ciudadanía</h4>
              <p className="text-xs text-gray-400">Mejor calidad del aire y servicios energéticos</p>
            </div>
            
            <div className="text-center p-4 bg-black bg-opacity-50 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] transition-all duration-300">
              <div className="w-16 h-16 mx-auto bg-[#00FF7F10] rounded-full flex items-center justify-center mb-3">
                <span className="text-[#00FF7F] text-3xl">🏫</span>
              </div>
              <h4 className="font-['Bebas_Neue'] mb-1">Escuelas y Universidades</h4>
              <p className="text-xs text-gray-400">Herramienta didáctica y participación en fabricación</p>
            </div>
            
            <div className="text-center p-4 bg-black bg-opacity-50 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] transition-all duration-300">
              <div className="w-16 h-16 mx-auto bg-[#00FF7F10] rounded-full flex items-center justify-center mb-3">
                <span className="text-[#00FF7F] text-3xl">🏭</span>
              </div>
              <h4 className="font-['Bebas_Neue'] mb-1">Empresas e Industrias</h4>
              <p className="text-xs text-gray-400">Autoabastecimiento y convenios público-privados</p>
            </div>
            
            <div className="text-center p-4 bg-black bg-opacity-50 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] transition-all duration-300">
              <div className="w-16 h-16 mx-auto bg-[#00FF7F10] rounded-full flex items-center justify-center mb-3">
                <span className="text-[#00FF7F] text-3xl">🔬</span>
              </div>
              <h4 className="font-['Bebas_Neue'] mb-1">Instituciones Científicas</h4>
              <p className="text-xs text-gray-400">Investigación aplicada con impacto real</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ImpactSection;