import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Settings, Cpu, LineChart, BatteryCharging } from 'lucide-react';

const TechnologiesSection: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section className="py-20 px-4 bg-black relative overflow-hidden" id="technologies">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <pattern id="circuit-pattern" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M10 10 H50 V50 H10 Z" fill="none" stroke="#00FF7F" strokeWidth="1" />
            <circle cx="10" cy="10" r="2" fill="#00FF7F" />
            <circle cx="50" cy="10" r="2" fill="#00FF7F" />
            <circle cx="50" cy="50" r="2" fill="#00FF7F" />
            <circle cx="10" cy="50" r="2" fill="#00FF7F" />
            <path d="M30 10 V30 H50" fill="none" stroke="#00FF7F" strokeWidth="1" />
          </pattern>
          <rect x="0" y="0" width="100%" height="100%" fill="url(#circuit-pattern)" />
        </svg>
      </div>

      <div className="container mx-auto relative z-10">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="text-center mb-16"
        >
          <motion.h2 
            variants={itemVariants}
            className="text-4xl md:text-5xl font-['Bebas_Neue'] mb-6 neon-text"
          >
            <span className="text-[#00FF7F]">Tecnologías</span> y Metodologías
          </motion.h2>
          
          <motion.p 
            variants={itemVariants}
            className="text-xl max-w-3xl mx-auto"
          >
            El desarrollo de T-Wind42 combina diversas tecnologías y enfoques metodológicos de vanguardia.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Technologies Column */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
          >
            <motion.div variants={itemVariants} className="mb-6">
              <div className="flex items-center mb-4">
                <Settings className="text-[#00FF7F] h-8 w-8 mr-3" />
                <h3 className="text-2xl font-['Bebas_Neue']">Tecnologías Aplicadas</h3>
              </div>
              
              <div className="space-y-4 pl-4">
                <div className="bg-black bg-opacity-50 p-4 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] transition-all duration-300">
                  <h4 className="text-lg font-['Bebas_Neue'] mb-1">Electromecánica Aplicada</h4>
                  <p className="text-sm text-gray-300">
                    Diseño y prototipado de turbinas Savonius de eje vertical optimizadas para flujos de aire urbanos irregulares.
                  </p>
                </div>
                
                <div className="bg-black bg-opacity-50 p-4 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] transition-all duration-300">
                  <h4 className="text-lg font-['Bebas_Neue'] mb-1">Sensórica Ambiental</h4>
                  <p className="text-sm text-gray-300">
                    Integración de sensores de CO₂, temperatura, vibración y viento con alta precisión y bajo consumo energético.
                  </p>
                </div>
                
                <div className="bg-black bg-opacity-50 p-4 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] transition-all duration-300">
                  <h4 className="text-lg font-['Bebas_Neue'] mb-1">Electrónica Embebida</h4>
                  <p className="text-sm text-gray-300">
                    Uso de microcontroladores y módulos IoT con conectividad optimizada para entornos urbanos.
                  </p>
                </div>
                
                <div className="bg-black bg-opacity-50 p-4 rounded-lg border border-[#00FF7F40] hover:border-[#00FF7F] transition-all duration-300">
                  <h4 className="text-lg font-['Bebas_Neue'] mb-1">Almacenamiento Energético</h4>
                  <p className="text-sm text-gray-300">
                    Baterías de segunda vida o módulos nuevos modulares con gestión inteligente de carga.
                  </p>
                </div>
              </div>
            </motion.div>
            
            <motion.div variants={itemVariants}>
              <div className="flex items-center mb-4">
                <Cpu className="text-[#00FF7F] h-8 w-8 mr-3" />
                <h3 className="text-2xl font-['Bebas_Neue']">Plataforma Digital</h3>
              </div>
              
              <div className="bg-gradient-to-r from-[#00FF7F10] to-transparent p-6 rounded-lg border border-[#00FF7F] mb-4">
                <h4 className="text-lg font-['Bebas_Neue'] mb-2">IoT y Analítica</h4>
                <ul className="space-y-2 text-sm text-gray-300">
                  <li className="flex items-start">
                    <span className="text-[#00FF7F] mr-2">•</span>
                    <span>Recolección y visualización de datos en tiempo real (Dashboards, APIs)</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#00FF7F] mr-2">•</span>
                    <span>Procesamiento local en el dispositivo (Edge Computing)</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#00FF7F] mr-2">•</span>
                    <span>Transmisión eficiente de datos con bajo consumo energético</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-gradient-to-r from-[#00FF7F10] to-transparent p-6 rounded-lg border border-[#00FF7F]">
                <h4 className="text-lg font-['Bebas_Neue'] mb-2">Inteligencia Artificial</h4>
                <ul className="space-y-2 text-sm text-gray-300">
                  <li className="flex items-start">
                    <span className="text-[#00FF7F] mr-2">•</span>
                    <span>Modelos predictivos de generación eléctrica basados en flujo vehicular</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#00FF7F] mr-2">•</span>
                    <span>Algoritmos de mantenimiento predictivo para optimizar la vida útil</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#00FF7F] mr-2">•</span>
                    <span>Clasificación de patrones de uso y condiciones operativas</span>
                  </li>
                </ul>
              </div>
            </motion.div>
          </motion.div>
          
          {/* Methodologies Column */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? 'visible' : 'hidden'}
          >
            <motion.div variants={itemVariants} className="mb-10">
              <div className="flex items-center mb-4">
                <LineChart className="text-[#00FF7F] h-8 w-8 mr-3" />
                <h3 className="text-2xl font-['Bebas_Neue']">Metodologías</h3>
              </div>
              
              <div className="space-y-6">
                <div className="relative pl-8 pb-6 border-l-2 border-[#00FF7F]">
                  <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-[#00FF7F]"></div>
                  <h4 className="text-lg font-['Bebas_Neue'] mb-1">Design Thinking</h4>
                  <p className="text-sm text-gray-300">
                    Desarrollo iterativo centrado en las necesidades reales de las ciudades y sus ciudadanos, con constante validación y refinamiento.
                  </p>
                </div>
                
                <div className="relative pl-8 pb-6 border-l-2 border-[#00FF7F]">
                  <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-[#00FF7F]"></div>
                  <h4 className="text-lg font-['Bebas_Neue'] mb-1">Lean Startup</h4>
                  <p className="text-sm text-gray-300">
                    Validación de hipótesis con bajo costo inicial y enfoque modular que permite pivotar y escalar eficientemente según los resultados.
                  </p>
                </div>
                
                <div className="relative pl-8 pb-6 border-l-2 border-[#00FF7F]">
                  <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-[#00FF7F]"></div>
                  <h4 className="text-lg font-['Bebas_Neue'] mb-1">IoT Edge Architecture</h4>
                  <p className="text-sm text-gray-300">
                    Procesamiento local en el dispositivo combinado con transmisión eficiente de datos, optimizando el consumo energético y la latencia.
                  </p>
                </div>
                
                <div className="relative pl-8">
                  <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-[#00FF7F]"></div>
                  <h4 className="text-lg font-['Bebas_Neue'] mb-1">Prototipado Rápido</h4>
                  <p className="text-sm text-gray-300">
                    Pruebas de campo en zonas de alta exposición al tráfico para validar la efectividad y resistencia del sistema en condiciones reales.
                  </p>
                </div>
              </div>
            </motion.div>
            
            <motion.div variants={itemVariants}>
              <div className="flex items-center mb-4">
                <BatteryCharging className="text-[#00FF7F] h-8 w-8 mr-3" />
                <h3 className="text-2xl font-['Bebas_Neue']">Manufactura Avanzada</h3>
              </div>
              
              <div className="bg-black bg-opacity-60 p-6 rounded-lg border border-[#00FF7F] shadow-[0_0_15px_rgba(0,255,127,0.2)]">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="text-center p-4">
                    <div className="w-16 h-16 mx-auto bg-[#00FF7F10] rounded-full flex items-center justify-center mb-2">
                      <span className="text-[#00FF7F] text-2xl">🖨️</span>
                    </div>
                    <h4 className="text-md font-['Bebas_Neue'] mb-1">Impresión 3D</h4>
                    <p className="text-xs text-gray-400">
                      Para carcasas, soportes y piezas estructurales, reduciendo costos y tiempos de desarrollo
                    </p>
                  </div>
                  
                  <div className="text-center p-4">
                    <div className="w-16 h-16 mx-auto bg-[#00FF7F10] rounded-full flex items-center justify-center mb-2">
                      <span className="text-[#00FF7F] text-2xl">♻️</span>
                    </div>
                    <h4 className="text-md font-['Bebas_Neue'] mb-1">Materiales Reciclables</h4>
                    <p className="text-xs text-gray-400">
                      Uso de materiales reciclables propios de la ciudad para reducir la huella ecológica
                    </p>
                  </div>
                </div>
                
                <div className="mt-4 p-3 bg-[#00FF7F10] rounded-lg text-sm text-center">
                  <p>
                    <span className="font-bold text-[#00FF7F]">Resultado:</span> Producción local, sostenible y escalable con menor huella de carbono
                  </p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default TechnologiesSection;