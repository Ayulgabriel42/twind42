import React, { useState, useEffect } from 'react';
import { Link } from 'react-scroll';
import { Menu, X, Wind } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const navLinks = [
    { to: 'home', label: 'Inicio' },
    { to: 'about', label: 'Acerca' },
    { to: 'problem', label: 'Problema' },
    { to: 'solution', label: 'Solución' },
    { to: 'impact', label: 'Impacto' },
    { to: 'technologies', label: 'Tecnologías' },
    { to: 'team', label: 'Equipo' },
    { to: 'contact', label: 'Contacto' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-black bg-opacity-90 py-2' : 'bg-transparent py-4'}`}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link 
            to="home" 
            spy={true} 
            smooth={true} 
            offset={-70} 
            duration={500} 
            className="flex items-center cursor-pointer"
          >
            <Wind className="text-[#00FF7F] h-8 w-8 mr-2" />
            <span className="font-['Bebas_Neue'] text-2xl text-white hover:text-[#00FF7F] transition-colors duration-300">
              T-WIND<span className="text-[#00FF7F]">42</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-6">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                spy={true}
                smooth={true}
                offset={-70}
                duration={500}
                activeClass="text-[#00FF7F] neon-text"
                className="font-['Bebas_Neue'] text-lg text-white hover:text-[#00FF7F] transition-colors duration-300 cursor-pointer"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-white focus:outline-none" onClick={toggleMenu}>
            {isOpen ? (
              <X className="h-6 w-6 text-[#00FF7F]" />
            ) : (
              <Menu className="h-6 w-6 hover:text-[#00FF7F]" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden bg-black bg-opacity-95 absolute top-full left-0 w-full py-4 px-6 shadow-lg">
            <div className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  spy={true}
                  smooth={true}
                  offset={-70}
                  duration={500}
                  activeClass="text-[#00FF7F] neon-text"
                  className="font-['Bebas_Neue'] text-lg text-white hover:text-[#00FF7F] transition-colors duration-300 cursor-pointer"
                  onClick={toggleMenu}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;