import React, { useEffect, useState } from 'react';
import { Element } from 'react-scroll';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import ProblemSection from './components/ProblemSection';
import SolutionSection from './components/SolutionSection';
import ImpactSection from './components/ImpactSection';
import TechnologiesSection from './components/TechnologiesSection';
import TeamSection from './components/TeamSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import Preloader from './components/Preloader';
import BackToTop from './components/BackToTop';
import './index.css';

const App: React.FC = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return <Preloader />;
  }

  return (
    <div className="relative">
      <Navbar />
      
      <Element name="home">
        <HeroSection />
      </Element>
      
      <div className="section-divider w-full my-4"></div>
      
      <Element name="about">
        <AboutSection />
      </Element>
      
      <div className="section-divider w-full my-4"></div>
      
      <Element name="problem">
        <ProblemSection />
      </Element>
      
      <div className="section-divider w-full my-4"></div>
      
      <Element name="solution">
        <SolutionSection />
      </Element>
      
      <div className="section-divider w-full my-4"></div>
      
      <Element name="impact">
        <ImpactSection />
      </Element>
      
      <div className="section-divider w-full my-4"></div>
      
      <Element name="technologies">
        <TechnologiesSection />
      </Element>
      
      <div className="section-divider w-full my-4"></div>
      
      <Element name="team">
        <TeamSection />
      </Element>
      
      <div className="section-divider w-full my-4"></div>
      
      <Element name="contact">
        <ContactSection />
      </Element>
      
      <Footer />
      <BackToTop />
    </div>
  );
};

export default App;